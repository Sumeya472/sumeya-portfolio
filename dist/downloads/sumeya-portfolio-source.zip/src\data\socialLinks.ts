import { SocialLink } from '../types';

export const socialLinks: SocialLink[] = [
  {
    name: 'GitHub',
    url: 'https://github.com/Sumeya472',
    icon: 'Github',
    label: 'Explore Repositories',
    highlight: true
  },
  {
    name: 'LinkedIn',
    url: 'https://www.linkedin.com/in/sumeya-seid-730028304/',
    icon: 'Linkedin',
    label: 'Connect on LinkedIn',
    highlight: true
  },
  {
    name: 'Telegram',
    url: 'https://t.me/Sumey_a',
    icon: 'Send',
    label: 'Chat on Telegram',
    highlight: true
  },
  {
    name: 'WhatsApp',
    url: 'https://wa.me/251980348942',
    icon: 'MessageCircle',
    label: 'Message on WhatsApp'
  },
  {
    name: 'LeetCode',
    url: 'https://leetcode.com/u/sumeya47/',
    icon: 'Code2',
    label: 'View Problem Solving'
  },
  {
    name: 'Codeforces',
    url: 'https://codeforces.com/profile/Sumeya_',
    icon: 'Terminal',
    label: 'View Competitive Profile'
  },
  {
    name: 'Instagram',
    url: 'https://instagram.com/sumeya_472',
    icon: 'Instagram',
    label: 'Follow on Instagram'
  }
];

export const personalInfo = {
  name: 'Sumeya Seid',
  firstName: 'Sumeya',
  lastName: 'Seid',
  email: 'sumeyaseid703@gmail.com',
  phone: '+251 980 348 942',
  phoneRaw: '+251980348942',
  location: 'Addis Ababa / Jimma, Ethiopia',
  university: 'Jimma University — Jimma Institute of Technology (JIT)',
  degree: 'BSc in Software Engineering',
  year: '4th-Year Student',
  expectedGraduation: '2028',
  internshipAvailability: 'Available for remote opportunities. Preparing for major university internship beginning February 2027, with openness to in-person or remote opportunities.',
  cvPath: '/files/Sumeya-Seid-CV.pdf'
};
